create database bdCursoX;

use bdCursoX;


create table tbAluno (
    codAluno int primary key auto_increment,
    nomeAluno varchar (50),
    enderecoAluno varchar (50),
    cidadeAluno varchar (50)
);

create table tbDisciplina (
    codDisc int primary key auto_increment,
    nomeDisc varchar (50),
    cargaHrDisc int,
    professorDisc varchar (50)
);

create table tbProfessor (
    codProf int primary key auto_increment,
    nomeProf varchar (50),
    enderecoProf varchar (50),
    cidadeProf varchar (50)
);


insert into tbAluno (nomeAluno, enderecoAluno, cidadeAluno) values
('Ana Beatriz Souza', 'Rua das Flores, 120', 'São Paulo'),
('Lucas Oliveira Santos', 'Av. Brasil, 450', 'Campinas'),
('Mariana Costa Lima', 'Rua das Palmeiras, 33', 'Santos'),
('Pedro Henrique Alves', 'Rua Sete de Setembro, 78', 'São Paulo'),
('Julia Ferreira Rocha', 'Av. Paulista, 900', 'São Paulo'),
('Gabriel Martins Silva', 'Rua do Comércio, 15', 'Sorocaba'),
('Isabela Ribeiro Gomes', 'Rua XV de Novembro, 210', 'Campinas'),
('Rafael Carvalho Mendes', 'Av. Central, 66', 'Santos'),
('Beatriz Almeida Castro', 'Rua das Acácias, 91', 'Sorocaba'),
('Matheus Pereira Nunes', 'Rua Alegria, 402', 'São Paulo');


insert into tbProfessor (nomeProf, enderecoProf, cidadeProf) values
('Carlos Eduardo Lima', 'Rua das Laranjeiras, 12', 'São Paulo'),
('Fernanda Moreira', 'Av. Independência, 340', 'Campinas'),
('Roberto Andrade', 'Rua da Paz, 55', 'Santos'),
('Patrícia Duarte', 'Rua Minas Gerais, 189', 'São Paulo'),
('Henrique Barbosa', 'Av. dos Estados, 720', 'Sorocaba');


insert into tbDisciplina (nomeDisc, cargaHrDisc, professorDisc) values
('Banco de Dados', 80, 'Carlos Eduardo Lima'),
('Programação Web', 100, 'Fernanda Moreira'),
('Redes de Computadores', 60, 'Roberto Andrade'),
('Engenharia de Software', 80, 'Patrícia Duarte'),
('Lógica de Programação', 60, 'Carlos Eduardo Lima');


select * from tbAluno;

select * from tbProfessor;

select * from tbDisciplina;


update tbDisciplina set cargaHrDisc = cargaHrDisc + 10 where codDisc > 0;

select * from tbDisciplina;


delete from tbDisciplina where professorDisc = 'Carlos Eduardo Lima';

select * from tbDisciplina;
